<?php
/**
 * Plugin Name: Elion — Revisor do Site
 * Description: Cria um novo portfólio ou revisa textos em um rascunho Elementor, preservando a página publicada.
 * Version: 2.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Elion Silva
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Elion_Site_Revisor {
    const ACTION = 'elion_preparar_rascunho';
    const VERSION = '2.1.0';

    public static function register() {
        add_action('admin_menu', function () {
            add_management_page('Revisor do Site', 'Revisor do Site', 'manage_options', 'elion-revisor', array(__CLASS__, 'screen'));
        });
        add_action('admin_post_' . self::ACTION, array(__CLASS__, 'submit'));
        add_filter('elementor/frontend/print_google_fonts', array(__CLASS__, 'allow_google_fonts'));
    }

    public static function allow_google_fonts($allow) {
        // This layout uses system fonts; preserve the behavior of every other page.
        if (is_singular('page') && get_post_meta(get_queried_object_id(), '_elion_portfolio_version', true)) {
            return false;
        }
        return $allow;
    }

    public static function screen() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $result = get_transient('elion_revisor_' . get_current_user_id());
        delete_transient('elion_revisor_' . get_current_user_id());
        ?>
        <div class="wrap">
            <h1>Preparar melhorias do site</h1>
            <p>Prepare um novo portfólio ou revise os textos existentes em um rascunho. A página publicada e a definição da página inicial serão preservadas.</p>
            <?php if (is_array($result)) : ?>
                <div class="notice <?php echo empty($result['error']) ? 'notice-success' : 'notice-error'; ?>">
                    <p><?php echo esc_html($result['message']); ?></p>
                    <?php if (!empty($result['id'])) : ?>
                        <p><a href="<?php echo esc_url(get_edit_post_link($result['id'], 'raw')); ?>">Abrir o rascunho</a> — depois escolha “Editar com Elementor”, se aplicável.</p>
                    <?php endif; ?>
                    <?php if (!empty($result['counts'])) : ?>
                        <ul><?php foreach ($result['counts'] as $label => $number) : ?>
                            <li><?php echo esc_html($label . ': ' . $number); ?></li>
                        <?php endforeach; ?></ul>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="<?php echo esc_attr(self::ACTION); ?>">
                <?php wp_nonce_field(self::ACTION); ?>
                <p><label for="elion-source">Página de origem</label></p>
                <?php wp_dropdown_pages(array('name' => 'source_id', 'id' => 'elion-source', 'selected' => (int) get_option('page_on_front'), 'show_option_none' => 'Selecione uma página', 'option_none_value' => '0')); ?>
                <p><label for="elion-mode">O que deseja preparar?</label><br>
                    <select id="elion-mode" name="mode">
                        <option value="redesign">Novo portfólio — apresentação, projetos e contato revisados</option>
                        <option value="text">Revisar somente textos e links da página existente</option>
                    </select>
                </p>
                <p><label for="elion-github">Usuário do GitHub</label><br>
                    <input id="elion-github" name="github_user" type="text" value="elionsilva" maxlength="39" required>
                </p>
                <p>O novo portfólio usa uma estrutura responsiva para Elementor, projetos selecionados e contato por e-mail e LinkedIn. Confira os fatos profissionais antes de publicar. Ele usa o e-mail público elion.silva@outlook.com.br, que você pode editar no Elementor.</p>
                <fieldset><legend>Opções para “Revisar somente textos”</legend>
                    <p><label><input name="hero" type="checkbox" value="1" checked> Simplificar o título e a apresentação conhecidos.</label></p>
                    <p><label><input name="github" type="checkbox" value="1" checked> Corrigir os trechos provisórios do GitHub reconhecidos.</label></p>
                </fieldset>
                <p>Credenciais da página original não são removidas nem revogadas. No modo de revisão de textos, rótulos reconhecidos são tratados na cópia; o novo portfólio usa conteúdo preparado separadamente.</p>
                <?php submit_button('Criar rascunho para revisão'); ?>
            </form>
            <h2>Antes de publicar</h2>
            <ul>
                <li>Confira apresentação, links e aparência no computador e celular.</li>
                <li>Confirme certificações, datas e resultados. O plugin não acrescenta qualificações ou números.</li>
                <li>Confira menus e links. O novo portfólio abre seu aplicativo de e-mail; não tem formulário nem serviço de envio.</li>
                <li>O novo portfólio usa Elementor Canvas, com cabeçalho próprio. Na revisão de textos, templates globais permanecem compartilhados.</li>
                <li>Remova a credencial da página pública original e, se real, faça a troca ou revogação no serviço correspondente.</li>
            </ul>
            <p>Publicar a cópia cria outra página: não substitui a inicial automaticamente. A revisão e a escolha da página inicial são feitas por você.</p>
        </div>
        <?php
    }

    private static function finish($result) {
        set_transient('elion_revisor_' . get_current_user_id(), $result, 300);
        wp_safe_redirect(admin_url('tools.php?page=elion-revisor'));
        exit;
    }

    public static function submit() {
        if (!current_user_can('manage_options') || !current_user_can('edit_pages')) {
            wp_die('Você não tem permissão para criar este rascunho.', '', array('response' => 403));
        }
        check_admin_referer(self::ACTION);
        $source_id = isset($_POST['source_id']) ? absint($_POST['source_id']) : 0;
        $source = get_post($source_id);
        if (!$source || $source->post_type !== 'page' || $source->post_status !== 'publish' || !current_user_can('edit_post', $source_id)) {
            self::finish(array('error' => true, 'message' => 'Escolha uma página publicada que você tenha permissão para editar.'));
        }
        $user = isset($_POST['github_user']) && is_string($_POST['github_user']) ? trim(wp_unslash($_POST['github_user'])) : '';
        if (!preg_match('/^[a-z0-9](?:[a-z0-9-]{0,37}[a-z0-9])?$/i', $user) || strpos($user, '--') !== false) {
            self::finish(array('error' => true, 'message' => 'Informe um nome de usuário válido do GitHub, sem URL.'));
        }
        $options = array('hero' => !empty($_POST['hero']), 'github' => !empty($_POST['github']), 'github_user' => $user);
        $mode = isset($_POST['mode']) && is_string($_POST['mode']) ? wp_unslash($_POST['mode']) : 'text';
        if (!in_array($mode, array('text', 'redesign'), true)) {
            self::finish(array('error' => true, 'message' => 'Selecione um modo válido.'));
        }
        if ($mode === 'redesign' && !did_action('elementor/loaded')) {
            self::finish(array('error' => true, 'message' => 'Ative o Elementor antes de preparar o novo portfólio.'));
        }
        $meta = array();
        foreach (array('_elementor_data', '_elementor_page_settings', '_elementor_edit_mode', '_elementor_template_type', '_elementor_version', '_elementor_pro_version', '_wp_page_template', '_thumbnail_id') as $key) {
            if (metadata_exists('post', $source_id, $key)) {
                $meta[$key] = get_post_meta($source_id, $key, true);
            }
        }
        $package = $mode === 'redesign' ? self::prepare_redesign($user) : self::prepare($source->post_content, $meta, $options);
        if (is_wp_error($package)) {
            self::finish(array('error' => true, 'message' => $package->get_error_message()));
        }
        if (array_sum($package['counts']) === 0) {
            self::finish(array('error' => true, 'message' => 'Nenhum trecho reconhecido foi encontrado. Nenhuma página foi criada. Revise o conteúdo diretamente no Elementor.'));
        }
        $fingerprint = hash('sha256', serialize(array(self::VERSION, $source_id, $source->post_content, $meta, $options, $mode, $package)));
        $existing = get_posts(array('post_type' => 'page', 'post_status' => 'draft', 'posts_per_page' => 1, 'meta_key' => '_elion_revision_key', 'meta_value' => $fingerprint, 'author' => get_current_user_id()));
        if ($existing) {
            self::finish(array('message' => 'Já existe um rascunho desta revisão. Ele foi preservado e não foi sobrescrito.', 'id' => $existing[0]->ID));
        }
        $draft = wp_insert_post(wp_slash(array(
            'post_type' => 'page', 'post_status' => 'draft',
            'post_title' => $mode === 'redesign' ? 'Elion Silva | Infraestrutura, Cloud e Educação em TI' : $source->post_title . ' — revisão',
            'post_content' => $package['content'], 'post_excerpt' => '',
            'post_author' => get_current_user_id(),
            'comment_status' => 'closed', 'ping_status' => 'closed',
        )), true);
        if (is_wp_error($draft)) {
            self::finish(array('error' => true, 'message' => 'O WordPress não conseguiu criar o rascunho. A origem foi preservada.'));
        }
        $ok = true;
        foreach ($package['meta'] as $key => $value) {
            $saved = update_post_meta($draft, $key, wp_slash($value));
            if ($saved === false && get_post_meta($draft, $key, true) !== $value) {
                $ok = false;
            }
        }
        if (!$ok) {
            wp_delete_post($draft, true);
            self::finish(array('error' => true, 'message' => 'Não foi possível preservar as configurações da cópia. O rascunho incompleto foi removido; a origem foi preservada.'));
        }
        if ($mode === 'redesign') {
            try {
                // Prepare only this draft's CSS; never clear caches of existing pages.
                $css = new \Elementor\Core\Files\CSS\Post($draft);
                $css->update();
                if ($css->get_meta('status') === 'file' && !is_readable($css->get_path())) {
                    throw new \RuntimeException('Draft CSS could not be written.');
                }
            } catch (\Throwable $error) {
                wp_delete_post($draft, true);
                self::finish(array('error' => true, 'message' => 'Não foi possível gerar os estilos do rascunho. Verifique a permissão de gravação dos arquivos do Elementor. A origem foi preservada.'));
            }
        }
        update_post_meta($draft, '_elion_revision_key', $fingerprint);
        update_post_meta($draft, '_elion_source_id', $source_id);
        self::finish(array('message' => 'Rascunho criado. Confira cada alteração antes de publicar.', 'id' => $draft, 'counts' => $package['counts']));
    }

    public static function prepare_redesign($github_user) {
        if (!is_string($github_user) || !preg_match('/^[a-z0-9](?:[a-z0-9-]{0,37}[a-z0-9])?$/i', $github_user) || strpos($github_user, '--') !== false) {
            return new WP_Error('elion_user', 'Informe um usuário válido do GitHub.');
        }
        $path = __DIR__ . '/portfolio.html';
        if (!is_readable($path)) {
            return new WP_Error('elion_template', 'O arquivo do novo portfólio não está disponível. Reinstale o ZIP completo.');
        }
        $html = file_get_contents($path);
        if ($html === false || $html === '' || strpos($html, '{{GITHUB_URL}}') === false) {
            return new WP_Error('elion_template', 'O modelo do portfólio está incompleto.');
        }
        $html = str_replace('{{GITHUB_URL}}', esc_url('https://github.com/' . $github_user), $html);
        if (self::has_credential($html) || preg_match('~<(?:html|head|body|title|script|form)\b~i', $html)) {
            return new WP_Error('elion_template', 'A estrutura do modelo não é adequada ao widget HTML.');
        }
        $elements = array(array(
            'id' => 'e510001', 'elType' => 'container', 'isInner' => false,
            'settings' => array('content_width' => 'full', 'flex_direction' => 'column', 'padding' => array('unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true), 'flex_gap' => array('column' => '0', 'row' => '0', 'unit' => 'px')),
            'elements' => array(array('id' => 'e510002', 'elType' => 'widget', 'widgetType' => 'html', 'settings' => array('html' => $html), 'elements' => array())),
        ));
        $json = wp_json_encode($elements, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return new WP_Error('elion_encoding', 'Não foi possível preparar o novo portfólio.');
        }
        return array('content' => '', 'meta' => array(
            '_elementor_data' => $json,
            '_elementor_edit_mode' => 'builder',
            '_elementor_template_type' => 'wp-page',
            '_elementor_page_settings' => array('hide_title' => 'yes'),
            '_wp_page_template' => 'elementor_canvas',
            '_elion_portfolio_version' => self::VERSION,
        ), 'counts' => array('Novo portfólio preparado' => 1));
    }

    public static function prepare($content, $meta, $options) {
        $counts = array('Título' => 0, 'Apresentação' => 0, 'GitHub' => 0, 'Rótulos de credenciais removidos' => 0);
        $elementor = null;
        if (isset($meta['_elementor_data'])) {
            $elementor = json_decode($meta['_elementor_data'], true);
            if (!is_array($elementor) || json_last_error() !== JSON_ERROR_NONE) {
                return new WP_Error('elion_json', 'Os dados do Elementor não puderam ser lidos. Nenhum rascunho foi criado.');
            }
        }
        $content = self::transform($content, $options, $counts);
        if ($elementor !== null) {
            // Change only widget settings: preserve element IDs, types, layout and tree.
            $elementor = self::elements($elementor, $options, $counts);
            $meta['_elementor_data'] = wp_json_encode($elementor, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($meta['_elementor_data'] === false) {
                return new WP_Error('elion_encoding', 'Não foi possível preparar os dados do Elementor.');
            }
        }
        if (isset($meta['_elementor_page_settings'])) {
            $meta['_elementor_page_settings'] = self::transform($meta['_elementor_page_settings'], $options, $counts);
        }
        if (self::has_credential($content) || self::has_credential($meta)) {
            return new WP_Error('elion_credential', 'Um rótulo de credencial permaneceu no conteúdo. Remova-o na origem antes de tentar novamente. Nenhum rascunho foi criado.');
        }
        return array('content' => $content, 'meta' => $meta, 'counts' => $counts);
    }

    private static function elements($elements, $options, &$counts) {
        foreach ($elements as &$element) {
            if (!is_array($element)) {
                continue;
            }
            if (isset($element['settings'])) {
                $element['settings'] = self::transform($element['settings'], $options, $counts);
            }
            if (isset($element['elements']) && is_array($element['elements'])) {
                $element['elements'] = self::elements($element['elements'], $options, $counts);
            }
        }
        unset($element);
        return $elements;
    }

    private static function transform($value, $options, &$counts) {
        if (is_array($value)) {
            // Elementor text and URL are separate settings on button/icon widgets.
            $is_github = false;
            foreach (array('text', 'title', 'editor') as $key) {
                if (isset($value[$key]) && is_string($value[$key]) && trim(strip_tags($value[$key])) === 'Inserir URL do GitHub profissional') {
                    $is_github = true;
                }
            }
            if (!empty($options['github']) && $is_github && isset($value['link']['url']) && in_array($value['link']['url'], array('', '#'), true)) {
                $value['link']['url'] = 'https://github.com/' . $options['github_user'];
                $counts['GitHub']++;
            }
            foreach ($value as $key => $part) {
                $value[$key] = self::transform($part, $options, $counts);
            }
            return $value;
        }
        if (!is_string($value)) {
            return $value;
        }
        if (!empty($options['hero'])) {
            $replacements = array(
                'Título' => array('Infraestrutura, Cloud e Transformação Técnica com visão de especialista', 'Infraestrutura Microsoft, Cloud e Educação em TI'),
                'Apresentação' => array('Analista de Infraestrutura com trajetória consolidada em ambientes corporativos, operação crítica, serviços Microsoft, redes, virtualização e modernização híbrida. Une execução técnica, governança operacional e didática profissional para entregar ambientes mais estáveis, seguros e preparados para crescimento em Azure, Microsoft 365 e multicloud.', 'Ajudo empresas a administrar e modernizar ambientes Microsoft e híbridos. Compartilho conhecimento técnico por meio de documentação, treinamento e projetos práticos.'),
            );
            foreach ($replacements as $label => $pair) {
                $number = 0;
                $value = str_replace($pair[0], $pair[1], $value, $number);
                $counts[$label] += $number;
            }
        }
        if (!empty($options['github'])) {
            $url = 'https://github.com/' . $options['github_user'];
            $value = preg_replace_callback('~<a\b([^>]*\bhref\s*=\s*)([\x22\x27])#\2([^>]*)>(.*?)</a>~is', function ($m) use ($url, &$counts) {
                if (strpos(strip_tags($m[4]), 'Inserir URL do GitHub profissional') === false) {
                    return $m[0];
                }
                $counts['GitHub']++;
                return '<a' . $m[1] . $m[2] . esc_url($url) . $m[2] . $m[3] . '>' . str_replace('Inserir URL do GitHub profissional', esc_html(preg_replace('~^https://~', '', $url)), $m[4]) . '</a>';
            }, $value);
            // A standalone label is replaced, but a count alone does not prove a link was fixed.
            $number = 0;
            $value = str_replace('Inserir URL do GitHub profissional', 'github.com/' . $options['github_user'], $value, $number);
            $counts['GitHub'] += $number;
        }
        $number = 0;
        $value = preg_replace('~\b(?:Password|Senha)\s*:\s*[^\s<]+~iu', '[credencial removida]', $value, -1, $number);
        $counts['Rótulos de credenciais removidos'] += $number;
        return $value;
    }

    private static function has_credential($value) {
        if (is_array($value)) {
            foreach ($value as $part) {
                if (self::has_credential($part)) {
                    return true;
                }
            }
            return false;
        }
        if (!is_string($value)) {
            return false;
        }
        $text = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return (bool) preg_match('~\b(?:Password|Senha)\s*:\s*\S+~iu', $text);
    }
}

Elion_Site_Revisor::register();
