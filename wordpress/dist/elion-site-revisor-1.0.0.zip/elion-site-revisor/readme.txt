=== Elion — Revisor do Site ===
Contributors: elionsilva
Tags: elementor, draft
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Prepara uma cópia em rascunho de uma página publicada para revisão manual.

== Instalação ==
Envie o ZIP em Plugins > Adicionar plugin > Enviar plugin e ative.
Abra Ferramentas > Revisor do Site. Selecione a página e crie o rascunho.
Abra a cópia no Elementor para conferir textos, links e aparência.

== Comportamento ==
Não altera a página original, a configuração da página inicial ou templates globais.
Não publica e não faz solicitações a serviços externos.
Trata somente os textos conhecidos e os rótulos de credenciais reconhecidos.
Os contadores mostram ocorrências em campos, não validação visual ou de todos os links.
Certificações e datas precisam de confirmação manual.
Publicar a cópia não substitui a inicial. Revise antes de decidir como aplicar as mudanças.
Remova credenciais da página pública original e troque ou revogue as reais.
Desativar o plugin preserva os rascunhos. Exclua a cópia manualmente se não precisar dela.
