=== Elion — Revisor do Site ===
Contributors: elionsilva
Tags: elementor, draft
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 2.0.1
License: GPL-2.0-or-later

Prepara um novo portfólio Elementor ou revisa textos em rascunho.

== Instalação ==
Envie o ZIP em Plugins > Adicionar plugin > Enviar plugin e ative.
Abra Ferramentas > Revisor do Site. Selecione a página e o modo de preparação.
Use Novo portfólio para o layout responsivo com projetos e contato por e-mail.
Abra o rascunho no Elementor para conferir textos, links e aparência.
O layout continua em um widget HTML, editável como código no Elementor.
Não é uma coleção de widgets visuais individuais.

== Comportamento ==
Não altera a página original, a configuração da página inicial ou templates globais.
Não publica e não faz solicitações a serviços externos.
No modo Revisar textos, trata somente trechos e rótulos reconhecidos.
O novo portfólio usa conteúdo preparado, sem formulário e sem scripts externos.
O contato por e-mail abre o aplicativo do visitante; não há serviço de envio.
Os contadores mostram ocorrências em campos, não validação visual ou de todos os links.
Certificações e datas precisam de confirmação manual.
Publicar a cópia não substitui a inicial. Revise antes de decidir como aplicar as mudanças.
Remova credenciais da página pública original e troque ou revogue as reais.
Desativar o plugin preserva os rascunhos. Exclua a cópia manualmente se não precisar dela.

== Atualização para 2.0.1 ==
Envie o ZIP pelo WordPress e escolha substituir a versão já instalada.
Não exclua nem publique automaticamente rascunhos anteriores.
A versão 2 acrescenta o modo Novo portfólio e mantém a revisão de textos.
A versão 2.0.1 prepara os estilos Elementor antes de disponibilizar o rascunho.
Enquanto ativo, evita fontes Google do Elementor nas páginas do novo portfólio,
que usa fontes do sistema. As demais páginas mantêm seu comportamento.
